from django.contrib import admin

from accounts.models import Shopper

admin.site.register(Shopper)